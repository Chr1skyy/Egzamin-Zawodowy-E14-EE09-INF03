<!DOCTYPE html>
<html lang="pl">

<head>
    <meta charset="UTF-8">
    <title>Blog kulinarny</title>
    <link rel="stylesheet" href="styl.css">
</head>

<body>
    <aside>
        <a href="przepisy.php?id=1">Sernik</a><br>
        <a href="przepisy.php?id=2">Sałatka</a><br>
        <a href="przepisy.php?id=3">Pankejki</a><br>
        <a href="przepisy.php?id=4">Nugetsy</a><br>
        <a href="przepisy.php?id=5">Łosoś</a><br>
        <a href="przepisy.php?id=6">Kociołek</a><br>
        <a href="przepisy.php?id=7">Jagnięcina</a><br>
        <a href="przepisy.php?id=8">Hamburgery</a><br>
        <a href="przepisy.php?id=9">Eklerki</a><br>
        <a href="przepisy.php?id=10">Churros</a>
        <p>Autor: Chr1skyy</p>
    </aside>
    <main>
        <?php
        $id = 7;
        if (isset($_GET['id'])) {
            $id = $_GET['id'];
        }
        $connect = mysqli_connect('localhost', 'root', '', 'przepisy');
        $query2 = "SELECT potrawy.nazwa, rodzaje.rodzaj FROM potrawy JOIN rodzaje ON potrawy.idRodzaje = rodzaje.idRodzaje WHERE potrawy.idPotrawy = $id;";
        $result = mysqli_query($connect, $query2);
        $row = mysqli_fetch_array($result);
        echo "<h1>{$row['rodzaj']}</h1>";

        $query1 = "SELECT nazwa, trudnosc, kalorie FROM potrawy WHERE idPotrawy = $id;";
        $result = mysqli_query($connect, $query1);
        $row = mysqli_fetch_array($result);
        echo "<h2>{$row['nazwa']}</h2>";
        if ($row['trudnosc'] == 1) $diff = 'łatwe';
        elseif ($row['trudnosc'] == 2) $diff = 'średnie';
        else $diff = 'trudne';
        echo "<p>Trudność: $diff, Kalorie: {$row['kalorie']}</p>";
        ?>
        <img src="img/separator.png" alt="przepis">
        <p>Alergeny:
            <?php
            $query3 = "SELECT alergeny.alergen FROM potrawy JOIN lista_alergenow ON potrawy.idPotrawy = lista_alergenow.idPotrawy JOIN alergeny ON lista_alergenow.idAlergeny = alergeny.idAlergeny WHERE potrawy.idPotrawy = $id;";
            $result = mysqli_query($connect, $query3);
            while ($row_a = mysqli_fetch_array($result)) {
                echo "{$row_a['alergen']} ";
            }
            ?>
        </p>
        <h3>SKŁADNIKI</h3>
        <ul>
            <li>Lorem 1 kg</li>
            <li>Ipsum 2 szt.</li>
            <li>Dolor 200 g</li>
            <li>Sit amet (szczypta)</li>
        </ul>
        <?php
        $query4 = "SELECT przepis, plik FROM potrawy WHERE idPotrawy = $id;";
        $result = mysqli_query($connect, $query4);
        $row_f = mysqli_fetch_array($result);
        ?>
        <p><?php echo $row_f['przepis']; ?></p>
    </main>
    <section style="background-image: url('img/<?= $row_f['plik'] ?>')">
        <h1>Blog Kulinarny</h1>
    </section>
    <?php mysqli_close($connect); ?>
</body>

</html>