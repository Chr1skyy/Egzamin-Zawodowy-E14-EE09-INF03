-- Tworzenie bazy danych
CREATE DATABASE IF NOT EXISTS matura
CHARACTER SET utf8
COLLATE utf8_polish_ci;

USE matura;

-- Tabela: matura_maturzysta
CREATE TABLE matura_maturzysta (
    id INT(11) PRIMARY KEY AUTO_INCREMENT,
    imie VARCHAR(20),
    nazwisko VARCHAR(20),
    szkola CHAR(2)
);

-- Tabela: matura_arkusz
CREATE TABLE matura_arkusz (
    symbol CHAR(3) PRIMARY KEY,
    rok INT(4),
    przedmiot VARCHAR(20),
    sesja VARCHAR(4)
);

-- Tabela: matura_wynik
CREATE TABLE matura_wynik (
    id INT(11) PRIMARY KEY AUTO_INCREMENT,
    maturzysta_id INT(11),
    symbol CHAR(3),
    punkty INT(11),
    FOREIGN KEY (maturzysta_id) REFERENCES matura_maturzysta(id),
    FOREIGN KEY (symbol) REFERENCES matura_arkusz(symbol)
);

-- Dane: maturzyści
INSERT INTO matura_maturzysta (imie, nazwisko, szkola) VALUES
('Adam', 'Kowalski', 'T3'),
('Anna', 'Nowak', 'T1'),
('Piotr', 'Wiśniewski', 'T3'),
('Kasia', 'Mazur', 'T2'),
('Tomasz', 'Lewandowski', 'T3'),
('Marek', 'Zieliński', 'T1'),
('Julia', 'Kaczmarek', 'T3'),
('Paweł', 'Wójcik', 'T2'),
('Natalia', 'Kamińska', 'T3'),
('Bartek', 'Dąbrowski', 'T1'),
('Michał', 'Król', 'T3'),
('Ewa', 'Piotrowska', 'T2'),
('Karol', 'Grabowski', 'T3'),
('Monika', 'Pawlak', 'T1'),
('Łukasz', 'Michalski', 'T3'),
('Alicja', 'Zając', 'T2'),
('Rafał', 'Sikora', 'T3'),
('Magda', 'Czarnecka', 'T1'),
('Krzysztof', 'Bąk', 'T3'),
('Patrycja', 'Lis', 'T2'),
('Damian', 'Urban', 'T3'),
('Ola', 'Wieczorek', 'T1'),
('Dawid', 'Kubiak', 'T3'),
('Karolina', 'Szulc', 'T2'),
('Marcin', 'Sadowski', 'T3'),
('Agata', 'Jaworska', 'T1'),
('Sebastian', 'Malinowski', 'T3'),
('Paulina', 'Pietrzak', 'T2'),
('Norbert', 'Kurek', 'T3'),
('Iwona', 'Tomczak', 'T1'),
('Robert', 'Kołodziej', 'T3');

-- Dane: arkusze
INSERT INTO matura_arkusz (symbol, rok, przedmiot, sesja) VALUES
('MAT', 2019, 'Matematyka', 'lato'),
('POL', 2018, 'Polski', 'lato'),
('ANG', 2020, 'Angielski', 'lato'),
('INF', 2021, 'Informatyka', 'lato'),
('BIO', 2017, 'Biologia', 'zima'),
('CHE', 2016, 'Chemia', 'lato');

-- Dane: wyniki (przykładowe)
INSERT INTO matura_wynik (maturzysta_id, symbol, punkty) VALUES
(1,'MAT',78),(1,'POL',65),(1,'ANG',90),
(3,'MAT',88),(3,'INF',92),
(5,'MAT',60),(5,'POL',55),
(7,'ANG',95),(7,'MAT',85),
(9,'BIO',70),(9,'CHE',68),
(11,'INF',100),(11,'MAT',90),
(13,'MAT',77),(13,'ANG',82),
(15,'POL',58),(15,'MAT',62),
(17,'INF',89),(17,'ANG',91),
(19,'MAT',73),(19,'CHE',66),
(21,'ANG',84),(21,'MAT',79),
(23,'POL',61),(23,'MAT',67),
(25,'INF',94),(25,'ANG',88),
(27,'MAT',81),(27,'POL',75),
(29,'ANG',90),(29,'INF',87),
(31,'MAT',99),(31,'INF',98),(31,'ANG',97);
