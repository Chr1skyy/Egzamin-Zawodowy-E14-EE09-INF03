function over(id, img) {
	document.getElementById(id).src = img;
}
function out(id, img) {
	document.getElementById(id).src = img;
}
function clicked(id, img) {
	over(id, img);
	document.getElementById("zmiana").src = img;

}